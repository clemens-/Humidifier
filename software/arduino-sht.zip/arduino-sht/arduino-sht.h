#ifndef ARDUINO_SHT_H
#define ARDUINO_SHT_H

#include "SHTSensor.h"

#endif
